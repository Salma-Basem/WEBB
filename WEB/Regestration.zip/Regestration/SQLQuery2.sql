﻿create table [dbo].[Coursename]
(

 courseID int identity (1,1) primary key,
 courseName nvarchar(40)

);